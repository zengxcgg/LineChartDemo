//
//  ViewController.m
//  LineChartDemo
//
//  Created by zengxcgg on 2016/12/14.
//  Copyright © 2016年 zengxcgg. All rights reserved.
//

#import "ViewController.h"
#import "ZXCLineChartView.h"

@interface ViewController ()

@property (nonatomic, strong) ZXCLineChartView *myView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _myView = [ZXCLineChartView loadLineViewWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 300)];
    [self.view addSubview:self.myView];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
