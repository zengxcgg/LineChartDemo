//
//  ZXCLineChartView.h
//  LineChartDemo
//
//  Created by zengxcgg on 2016/12/14.
//  Copyright © 2016年 zengxcgg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXCLineChartView : UIView

+ (ZXCLineChartView *)loadLineViewWithFrame:(CGRect)frame;

@end
