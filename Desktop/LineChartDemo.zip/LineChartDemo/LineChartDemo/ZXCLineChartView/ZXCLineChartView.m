//
//  ZXCLineChartView.m
//  LineChartDemo
//
//  Created by zengxcgg on 2016/12/14.
//  Copyright © 2016年 zengxcgg. All rights reserved.
//

#import "ZXCLineChartView.h"

@interface ZXCLineChartView()

@property (nonatomic, strong) CAShapeLayer      *lineChartLayer;
@property (nonatomic, strong) UIBezierPath      *path1;

/** 渐变背景视图 */
@property (nonatomic, strong) UIView            *gradient_backgroundView;
/** 渐变图层 */
@property (nonatomic, strong) CAGradientLayer   *gradient_layer;
/** 颜色数组 */
@property (nonatomic, strong) NSMutableArray    *colors_arr;

@end

@implementation ZXCLineChartView
{
    CGFloat boundX ;
    CGFloat boundY ;
}

+ (ZXCLineChartView *)loadLineViewWithFrame:(CGRect)frame{
    return [[ZXCLineChartView alloc] initWithFrame:frame];
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
        boundX = self.bounds.size.width * 0.1;
        boundY = self.bounds.size.height * 0.1;
        
        self.backgroundColor = [UIColor colorWithRed:23/255.0 green:34/255.0 blue:42/255.0 alpha:1];
        [self createXLine];
        [self createYLine];
        [self drawGradientBackgroundView];
        [self setDashLine];
        [self drawLine];
        
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 2.0);
    CGContextSetRGBStrokeColor(context, 97/255.0, 150/255.0, 198/255.0, 1);
    CGContextMoveToPoint(context, boundX, boundY);
    // Y 轴
    CGContextAddLineToPoint(context, boundX, rect.size.height - boundY);
    // X 轴
    CGContextAddLineToPoint(context, rect.size.width -  boundX, rect.size.height - boundY);
    
    
    // X轴 箭头
    CGContextMoveToPoint(context, rect.size.width -  boundX - 5, rect.size.height - boundY -5);
    CGContextAddLineToPoint(context, rect.size.width -  boundX, rect.size.height - boundY);
    CGContextAddLineToPoint(context, rect.size.width -  boundX - 5, rect.size.height - boundY + 5);
    
    // Y轴 箭头
    CGContextMoveToPoint(context, boundX - 5, boundY + 5);
    CGContextAddLineToPoint(context, boundX, boundY);
    CGContextAddLineToPoint(context, boundX + 5, boundY + 5);
    
    // 结束绘制
    CGContextStrokePath(context);
}

#pragma mark 创建x轴的数据
- (void)createXLine{
    CGFloat  month = 12;
    for (NSInteger i = 0; i < month; i++) {
        UILabel * x_label = [[UILabel alloc]initWithFrame:CGRectMake((self.frame.size.width - 2 * boundX)/month * i + boundX, self.frame.size.height - boundY + boundY*0.2, (self.frame.size.width - 2 * boundX)/month- 5, boundY/2)];
        //       LabelMonth.backgroundColor = [UIColor greenColor];
        x_label.tag = 1000 + i;
        x_label.text = [NSString stringWithFormat:@"%ld月",i+1];
        x_label.font = [UIFont systemFontOfSize:8];
        x_label.transform = CGAffineTransformMakeRotation(M_PI * 0.3);
        x_label.textColor = [UIColor whiteColor];
        [self addSubview:x_label];
    }
    
}
#pragma mark 创建y轴数据
- (void)createYLine{
    CGFloat Y_Value = 6;
    for (NSInteger i = 0; i < Y_Value; i++) {
        UILabel * y_label = [[UILabel alloc]initWithFrame:CGRectMake(0, (self.frame.size.height - 2 * boundY)/Y_Value * i + boundX, boundY, boundY/2.0)];
        //   labelYdivision.backgroundColor = [UIColor greenColor];
        y_label.tag = 2000 + i;
        y_label.text = [NSString stringWithFormat:@"%.0f",(Y_Value - i)*100];
        y_label.font = [UIFont systemFontOfSize:10];
        y_label.textColor = [UIColor whiteColor];
        y_label.textAlignment = NSTextAlignmentCenter;
        [self addSubview:y_label];
    }
}

- (void)drawGradientBackgroundView {
    // 渐变背景视图（不包含坐标轴）
    self.gradient_backgroundView = [[UIView alloc] initWithFrame:CGRectMake(boundX, boundY, self.bounds.size.width - boundX*2, self.bounds.size.height - 2*boundY)];
    [self addSubview:self.gradient_backgroundView];
    
    /** 创建并设置渐变背景图层 */
    //初始化CAGradientlayer对象，使它的大小为渐变背景视图的大小
    self.gradient_layer = [CAGradientLayer layer];
    self.gradient_layer.frame = self.gradient_backgroundView.bounds;
    
    //设置渐变区域的起始和终止位置（范围为0-1），即渐变路径
    self.gradient_layer.startPoint = CGPointMake(0, 0.0);
    self.gradient_layer.endPoint = CGPointMake(1.0, 0.0);
    
    //设置颜色的渐变过程
    // [UIColor colorWithRed:67 / 255.0 green:106 / 255.0 blue:140 / 255.0 alpha:1.0]
    // [UIColor colorWithRed:59 / 255.0 green:92 / 255.0 blue:120 / 255.0 alpha:1.0]
    
    self.colors_arr = [NSMutableArray arrayWithArray:@[(__bridge id)[UIColor colorWithRed:95 / 255.0 green:148 / 255.0 blue:195 / 255.0 alpha:0.4].CGColor, (__bridge id)[UIColor colorWithRed:59 / 255.0 green:92 / 255.0 blue:120 / 255.0 alpha:0.4].CGColor]];
    
    self.gradient_layer.colors = self.colors_arr;
    
    //将CAGradientlayer对象添加在我们要设置背景色的视图的layer层
    [self.gradient_backgroundView.layer addSublayer:self.gradient_layer];
    
}

- (void)setDashLine{
    
    for (NSInteger i = 1;i < 6; i++ ) {
        
        UILabel * label1 = (UILabel*)[self viewWithTag:2000 + i];//获取Y轴数据label的位置根据其位置画横虚线
        
        UIBezierPath * path1 = [UIBezierPath bezierPath];
        [path1 moveToPoint:CGPointMake( 0, label1.frame.origin.y - boundY)];
        [path1 addLineToPoint:CGPointMake(self.frame.size.width - 2 * boundX,label1.frame.origin.y - boundY)];
        
        
        CAShapeLayer *dashLayer = [CAShapeLayer layer];
        dashLayer.strokeColor = [UIColor whiteColor].CGColor;
        dashLayer.fillColor = [UIColor clearColor].CGColor;
        // 设置线条宽度
        dashLayer.lineWidth = 1.0;
        //  设置虚线  每间隔十个画一条线，总共十条
        dashLayer.lineDashPattern = @[@10, @10];
        
        dashLayer.path = path1.CGPath;
        [self.gradient_backgroundView.layer addSublayer:dashLayer];
    }
    
}

#pragma mark 画折线图
- (void)drawLine{
    
    UILabel * label = (UILabel*)[self viewWithTag:1000];//根据横坐标上面的label 获取直线关键点的x 值
    UIBezierPath * path = [[UIBezierPath alloc]init];
    
    self.path1 = path;
    
    [path moveToPoint:CGPointMake( label.frame.origin.x - boundX + 7, (600 -arc4random()%600) /600.0 * (self.frame.size.height - boundY*2 )  )];
    
    //创建折现点标记
    for (NSInteger i = 1; i< 12; i++) {
        UILabel * label1 = (UILabel*)[self viewWithTag:1000 + i];
        CGFloat  arc = arc4random()%600;  //折线点目前给的是随机数
        [path addLineToPoint:CGPointMake(label1.frame.origin.x - boundX,  (600 -arc) /600.0 * (self.frame.size.height - boundY*2 ) )];
        UILabel * falglabel = [[UILabel alloc]initWithFrame:CGRectMake(label1.frame.origin.x , (600 -arc) /600.0 * (self.frame.size.height - boundY*2 )+ boundY  , 30, 15)];
        //  falglabel.backgroundColor = [UIColor blueColor];
        falglabel.tag = 3000+ i;
        falglabel.text = [NSString stringWithFormat:@"%.1f",arc];
        falglabel.font = [UIFont systemFontOfSize:8.0];
        [self addSubview:falglabel];
    }
    [path stroke];
    
    self.lineChartLayer = [CAShapeLayer layer];
    self.lineChartLayer.path = path.CGPath;
    self.lineChartLayer.strokeColor = [UIColor whiteColor].CGColor;
    self.lineChartLayer.fillColor = [[UIColor clearColor] CGColor];
    
    self.lineChartLayer.lineWidth = 2;
    self.lineChartLayer.lineCap = kCALineCapRound;
    self.lineChartLayer.lineJoin = kCALineJoinRound;
    
    [self.gradient_backgroundView.layer addSublayer:self.lineChartLayer];//直接添加导视图上
    
    CABasicAnimation *pathAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    pathAnimation.duration = 3;
    pathAnimation.repeatCount = 1;
    pathAnimation.removedOnCompletion = YES;
    pathAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    pathAnimation.toValue = [NSNumber numberWithFloat:1.0f];
    // 设置动画代理，动画结束时添加一个标签，显示折线终点的信息
    pathAnimation.delegate = self;
    [self.lineChartLayer addAnimation:pathAnimation forKey:@"strokeEnd"];
    
    
}


@end
